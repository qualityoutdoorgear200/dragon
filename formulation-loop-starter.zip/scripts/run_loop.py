
import argparse, os, json, yaml
from pathlib import Path
from src.loop.formulation_loop import loop_once

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dossier', required=True, help='Path to dossier text file')
    ap.add_argument('--bounds', required=True, help='Path to bounds.yaml')
    ap.add_argument('--out', required=True, help='Output directory')
    args = ap.parse_args()

    with open(args.dossier, 'r', encoding='utf-8') as f:
        dossier = f.read()
    with open(args.bounds, 'r', encoding='utf-8') as f:
        bounds = yaml.safe_load(f)

    loop_once(dossier, bounds, args.out)
    print(f"Artifacts written to {args.out}")

if __name__ == '__main__':
    main()
