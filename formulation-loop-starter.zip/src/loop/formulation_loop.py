
import os, json, re
from dataclasses import dataclass, asdict
from typing import Dict, List
from .utils import to_pct, sum_percent, slugify
from ..calc.hlb_solver import required_hlb_for_oil_phase, emulsifier_blend_hlb
from ..calc.preservation import compute_preservation
from ..calc.nlc_solid_fraction import estimate_nlc_solid_fraction
from ..calc.ph_rheology import ph_trim_plan, rheology_risk

@dataclass
class Scorecard:
    mass_balance_ok: bool
    pH_target: float
    pH_trim_plan_g: Dict[str, float]
    rheology_risk: str
    nlc_solid_fraction_est: float
    hlb: Dict
    preservation: Dict
    compat_flags: List[str]
    sensory_score: float
    cost_score: float
    ee_proxy: Dict[str, float]
    color_stability_proxy: float
    net_score: float

def parse_dossier(text: str) -> Dict:
    res = {"phases": {}, "manufacturing": ""}
    phase = None
    for line in text.splitlines():
        if line.strip().startswith("Phase "):
            phase = line.strip()
            res["phases"][phase] = {}
        elif phase and line.strip() and not line.strip().startswith("#") and not line.startswith("Ingredient"):
            parts = re.split(r"\s{2,}|\t", line.strip())
            if len(parts) >= 2:
                name = parts[0]
                try:
                    g = float(parts[-1])
                    res["phases"][phase][name] = g
                except ValueError:
                    pass
        elif line.strip().startswith("DAY"):
            res["manufacturing"] += line + "\n"
    return res

def compute_oil_phase(phases: Dict[str, Dict[str, float]]) -> Dict[str, float]:
    oil = {}
    for k in phases:
        if "Phase B" in k:
            for ing, g in phases[k].items():
                oil[ing] = oil.get(ing, 0.0) + g
    return oil

def compute_emulsifiers(phases: Dict[str, Dict[str, float]]) -> Dict[str, float]:
    emu = {}
    for k in phases:
        if "Phase B" in k:
            for ing, g in phases[k].items():
                if any(x in ing for x in ["Olivem", "Montanov", "Glyceryl Stearate"]):
                    emu[ing] = emu.get(ing, 0.0) + g
    return emu

def compat_flags(phases: Dict[str, Dict[str, float]]) -> List[str]:
    flags = []
    aphase = None
    for k in phases:
        if k.startswith("Phase A"):
            aphase = phases[k]
            break
    if aphase:
        chelators = aphase.get("Sodium Phytate", 0.0) + aphase.get("Tetrasodium Glutamate Diacetate", 0.0)
    else:
        chelators = 0.0
    cu = 0.0
    for k in phases:
        for name in phases[k]:
            if any(x in name for x in ["Copper Tripeptide","GHK-Cu","AHK-Cu"]):
                cu += phases[k][name]
    if chelators>0 and cu>0:
        flags.append("Cu×chelator")
    if aphase and "Xanthan Gum (pre-slurry)†" in aphase:
        flags.append("anionic_polymer×leaked_Cu")
    if any("Bakuchiol" in ing for ings in phases.values() for ing in ings):
        flags.append("high_irritation_stack")
    if any(x in (list(phases.get('Phase B — Oil NLC',{}).keys())) for x in ["Stearic Acid","Glyceryl Stearate","Olivem 1000","Montanov 202"]):
        flags.append("soaping_risk")
    return flags

def propose_bounded_edits(phases: Dict[str, Dict[str, float]], bounds: Dict) -> List[Dict]:
    edits = []
    b = phases.get('Phase B — Oil NLC', {})
    ipm = b.get("Isopropyl Myristate", 0.0)
    if ipm>=10.0:
        edits.append({"op":"replace","path":"/PhaseB1/Isopropyl Myristate","value":"C12-15 Alkyl Benzoate 10.00 g"})
    sa = b.get("Stearic Acid", 0.0)
    if sa>0.5:
        edits.append({"op":"replace","path":"/PhaseB1/Stearic Acid","value":"0.50 g"})
        gms = b.get("Glyceryl Stearate", 0.0) + 0.5
        edits.append({"op":"replace","path":"/PhaseB1/Glyceryl Stearate","value":f"{gms:.2f} g"})
    for k in phases:
        if k.startswith("Phase A"):
            a = phases[k]
            phy = a.get("Sodium Phytate", 0.0)
            glda = a.get("Tetrasodium Glutamate Diacetate", 0.0)
            total = phy+glda
            if total>0.15:
                new_phy = max(0.05, phy-0.15)
                new_glda = min(0.10, glda)
                edits.append({"op":"replace","path":"/PhaseA/Sodium Phytate","value":f"{new_phy:.2f} g"})
                edits.append({"op":"replace","path":"/PhaseA/Tetrasodium Glutamate Diacetate","value":f"{new_glda:.2f} g"})
            break
    return edits

def apply_edits(phases: Dict[str, Dict[str, float]], edits: List[Dict]) -> Dict[str, Dict[str, float]]:
    import copy
    new = copy.deepcopy(phases)
    for e in edits:
        if e["op"]=="replace":
            if "PhaseB1" in e["path"]:
                key = 'Phase B — Oil NLC'
            else:
                key = [k for k in new if k.startswith("Phase A")][0]
            val = e["value"]
            try:
                grams = float(val.split()[-2])
            except:
                continue
            name = " ".join(val.split()[:-2])
            new[key][name] = grams
    return new

def loop_once(dossier_text: str, bounds: Dict, out_dir: str):
    parsed = parse_dossier(dossier_text)
    phases = parsed["phases"]
    total = sum([g for ph in phases.values() for g in ph.values()]) or bounds.get("batch_size_g", 515.0)

    oil = compute_oil_phase(phases)
    emu = compute_emulsifiers(phases)

    req_hlb = required_hlb_for_oil_phase(oil)
    emu_hlb = emulsifier_blend_hlb(emu)

    phase_d = {}
    for k in phases:
        if "Phase D" in k:
            phase_d.update(phases[k])
    pres = compute_preservation(phase_d, total)

    nlc_frac = estimate_nlc_solid_fraction(oil)
    trim_plan = ph_trim_plan(5.8)
    rheo = rheology_risk(electrolyte_load_g=1.0, total_batch_g=total)
    flags = compat_flags(phases)
    ee_proxy = {"peptide": 6.0, "cu": 8.0}
    sensory = 6.0
    cost = 5.0
    color = 6.0
    net = 10.0 + pres.coverage_score + (10.0 - (5.0 if "soaping_risk" in flags else 0.0)) + (10.0 - (3.0 if rheo=="high" else 0.0)) + sensory + cost + ee_proxy["cu"] + color

    score = {
        "mass_balance_ok": abs(total - bounds.get("batch_size_g", 515.0))<0.5,
        "pH_target": 5.8,
        "pH_trim_plan_g": trim_plan,
        "rheology_risk": rheo,
        "nlc_solid_fraction_est": nlc_frac,
        "hlb": {"required": req_hlb, "blend": {"Olivem/Montanov/GMS": emu_hlb}, "delta": abs(req_hlb-emu_hlb)},
        "preservation": {
            "phenoxyethanol_%": pres.phenoxyethanol_pct,
            "ehg_%": pres.ehg_pct,
            "caprylyl_glycol_%": pres.caprylyl_glycol_pct,
            "glyceryl_caprylate_%": pres.glyceryl_caprylate_pct,
            "coverage_score": pres.coverage_score
        },
        "compat_flags": flags,
        "sensory_score": sensory,
        "cost_score": cost,
        "ee_proxy": ee_proxy,
        "color_stability_proxy": color,
        "net_score": net
    }

    edits = propose_bounded_edits(phases, bounds)
    new_phases = apply_edits(phases, edits)

    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "scorecard.json"), "w") as f:
        json.dump(score, f, indent=2)
    with open(os.path.join(out_dir, "changeset.json"), "w") as f:
        json.dump(edits, f, indent=2)
    with open(os.path.join(out_dir, "summary.md"), "w") as f:
        f.write(f"# Summary\n- Required HLB ≈ {req_hlb:.2f}; emulsifier blend HLB ≈ {emu_hlb:.2f} (Δ {abs(req_hlb-emu_hlb):.2f}).\n"
                f"- NLC solid fraction estimate @25°C ≈ {nlc_frac:.2f}.\n"
                f"- Preservation coverage score ≈ {pres.coverage_score:.1f}.\n"
                f"- Flags: {', '.join(flags) if flags else 'none'}.\n"
                f"- Proposed edits: {len(edits)} (see changeset.json).\n")
    with open(os.path.join(out_dir, "updated_dossier.md"), "w") as f:
        f.write("## TODO: Codex to render updated vX.Y dossier based on changeset\n")
    with open(os.path.join(out_dir, "citations.json"), "w") as f:
        json.dump([], f)
    with open(os.path.join(out_dir, "next_test_plan.md"), "w") as f:
        f.write("- Cu-EE grid; color ΔE* at 0/24/168 h @ 25/40°C\n- Rheology 10/100 s^-1; electrolyte add-back\n- Rapid preservation screen before PET\n- Sensory A/B for ester swap\n")
