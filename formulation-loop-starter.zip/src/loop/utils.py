
import re, unicodedata

def to_pct(grams, total):
    return (grams/total)*100 if total else 0.0

def sum_percent(d: dict, total: float):
    return sum((g/total)*100 for g in d.values()) if total else 0.0

def slugify(value):
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
    value = re.sub(r'[^\w\s-]', '', value).strip().lower()
    return re.sub(r'[-\s]+', '-', value)
