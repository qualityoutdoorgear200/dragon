
from dataclasses import dataclass
from typing import Dict

@dataclass
class PreservationBreakdown:
    phenoxyethanol_pct: float
    ehg_pct: float
    caprylyl_glycol_pct: float
    glyceryl_caprylate_pct: float
    coverage_score: float

def compute_preservation(phase_d: Dict[str, float], total_batch_g: float) -> PreservationBreakdown:
    pe9010_g = phase_d.get("Phenoxyethanol & Ethylhexylglycerin", 0.0)
    phenoxy = (pe9010_g/total_batch_g)*0.90*100
    ehg = (pe9010_g/total_batch_g)*0.10*100
    cap = (phase_d.get("Caprylyl Glycol", 0.0)/total_batch_g)*100
    glycap = (phase_d.get("Glyceryl Caprylate", 0.0)/total_batch_g)*100

    coverage = 0.0
    coverage += min(phenoxy/0.8, 1.0)*3.0
    coverage += min(ehg/0.1, 1.0)*1.0
    coverage += min(cap/0.5, 1.0)*3.0
    coverage += min(glycap/0.1, 1.0)*3.0
    coverage = min(10.0, coverage)

    return PreservationBreakdown(phenoxy, ehg, cap, glycap, coverage)
