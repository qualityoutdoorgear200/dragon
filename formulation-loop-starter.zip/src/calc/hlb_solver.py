
from typing import Dict

REQUIRED_HLB = {
    "Caprylic/Capric Triglyceride": 5.0,
    "Isopropyl Myristate": 11.0,
    "C12-15 Alkyl Benzoate": 10.0,
    "Squalane": 7.5,
    "Olive Squalane": 7.5,
    "Theobroma grandiflorum Seed Butter": 8.0,
    "Butyrospermum parkii Butter": 8.0
}

EMULSIFIERS_HLB = {
    "Cetearyl Olivate/Sorbitan Olivate": 9.5,
    "Arachidyl/Behenyl/Capryl Glucoside": 10.0,
    "Glyceryl Stearate": 3.8
}

def required_hlb_for_oil_phase(oil_phase: Dict[str,float]) -> float:
    total = sum(oil_phase.values()) or 1.0
    hlb = 0.0
    wsum = 0.0
    for name, pct in oil_phase.items():
        if name in REQUIRED_HLB:
            w = pct/total
            hlb += w*REQUIRED_HLB[name]
            wsum += w
    return hlb if wsum>0 else 8.0

def emulsifier_blend_hlb(blend: Dict[str,float]) -> float:
    total = sum(blend.values()) or 1.0
    val = 0.0
    for name, pct in blend.items():
        h = EMULSIFIERS_HLB.get(name)
        if h is not None:
            val += (pct/total)*h
    return val
