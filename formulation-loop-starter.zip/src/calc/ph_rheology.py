
from typing import Dict

def ph_trim_plan(target_ph: float = 5.8, citrate_stock_pct: float = 10.0, bicarb_stock_pct: float = 10.0) -> Dict[str, float]:
    return {
        "10% citrate (to lower pH by ~0.1)": 0.5,
        "10% NaHCO3 (to raise pH by ~0.1)": 0.5
    }

def rheology_risk(electrolyte_load_g: float, total_batch_g: float) -> str:
    pct = (electrolyte_load_g/total_batch_g)*100
    if pct >= 1.0:
        return "high"
    if pct >= 0.3:
        return "medium"
    return "low"
