
from typing import Dict
import math

MELTING_POINTS = {
    "Theobroma grandiflorum Seed Butter": 32.0,
    "Butyrospermum parkii Butter": 35.0,
    "Glyceryl Stearate": 58.0,
    "Stearic Acid": 69.0,
    "Squalane": -38.0,
    "Caprylic/Capric Triglyceride": -5.0,
    "Isopropyl Myristate": -4.0,
    "C12-15 Alkyl Benzoate": -2.0
}

def fraction_solid_at_25c(mp: float) -> float:
    k = 0.25
    x0 = 27.5
    return 1/(1+math.exp(-k*(mp - x0)))

def estimate_nlc_solid_fraction(lipid_phase: Dict[str, float]) -> float:
    total = sum(lipid_phase.values()) or 1.0
    f = 0.0
    for name, pct in lipid_phase.items():
        mp = MELTING_POINTS.get(name)
        frac = fraction_solid_at_25c(mp) if mp is not None else 0.5
        f += (pct/total)*frac
    return f
