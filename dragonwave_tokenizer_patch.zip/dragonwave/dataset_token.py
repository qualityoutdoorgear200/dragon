
import torch
def build_token_dataset_from_file(path: str, tokenizer, seq_len: int = 2048, num_samples: int = 8192):
    text = open(path, "r", encoding="utf-8").read()
    ids = tokenizer.encode(text).ids
    if len(ids) < seq_len + 1:
        reps = (seq_len + 1 + len(ids) - 1) // max(1, len(ids))
        ids = (ids * reps)[: seq_len + 1]
    ids = torch.tensor(ids, dtype=torch.long)
    windows = []
    step = seq_len
    for i in range(0, max(0, len(ids) - (seq_len + 1)), step):
        x = ids[i : i + seq_len]
        y = ids[i + 1 : i + 1 + seq_len]
        windows.append((x, y))
        if num_samples > 0 and len(windows) >= num_samples:
            break
    return windows
def collate(batch):
    xs, ys = zip(*batch)
    return torch.stack(xs), torch.stack(ys)
